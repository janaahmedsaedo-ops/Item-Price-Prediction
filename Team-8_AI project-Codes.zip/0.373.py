import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from catboost import CatBoostRegressor


train_raw = pd.read_csv("train.csv")
test_raw  = pd.read_csv("test.csv")


def preprocess(df):
    df = df.copy()
    df["X3"] = df["X3"].replace({"low fat": "Low Fat", "LF": "Low Fat", "reg": "Regular"})
    df["X2"] = df["X2"].fillna(df["X2"].median())
    df["X9"] = df["X9"].fillna(df["X9"].mode()[0])
    df["X4"] = df["X4"].replace(0.0, df[df["X4"] > 0]["X4"].mean())
    df["Outlet_Age"] = 2026 - df["X8"]
    df["Price_per_Visibility"] = df["X6"] / (df["X4"] + 0.001)
    df["MRP_x_Age"] = df["X6"] * df["Outlet_Age"]
    df = df.drop(columns=["X8"])
    return df

train = preprocess(train_raw)
test  = preprocess(test_raw)

X = train.drop(columns=["Y"])
y = train["Y"]
X_test = test.copy()

cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
cat_idx  = [X.columns.get_loc(c) for c in cat_cols]

def to_str(df):
    df = df.copy()
    for col in cat_cols:
        df[col] = df[col].astype(str)
    return df

X_str      = to_str(X)
X_test_str = to_str(X_test)


X_tr, X_val, y_tr, y_val = train_test_split(X_str, y, test_size=0.2, random_state=20)
cat_idx_tr = [X_tr.columns.get_loc(c) for c in cat_cols]

m_val = CatBoostRegressor(
    loss_function="MAE",
    iterations=3000,
    learning_rate=0.05,
    depth=7,
    l2_leaf_reg=1,
    random_seed=42,
    verbose=False
)
m_val.fit(X_tr, y_tr, cat_features=cat_idx_tr, eval_set=(X_val, y_val),
          early_stopping_rounds=100, use_best_model=True)

best_iter = m_val.best_iteration_
val_mae   = mean_absolute_error(y_val, m_val.predict(X_val))
print(f"Validation MAE: {val_mae:.4f}")
print(f"Best iteration: {best_iter}")


m_full = CatBoostRegressor(
    loss_function="MAE",
    iterations=best_iter,
    learning_rate=0.05,
    depth=7,
    l2_leaf_reg=1,
    random_seed=42,
    verbose=False
)
m_full.fit(X_str, y, cat_features=cat_idx)


test_preds = m_full.predict(X_test_str)

submission = pd.DataFrame({
    test_raw.columns[0]: range(len(test_preds)),
    "Y": test_preds
})

submission.to_csv("submission_catboost_final.csv", index=False)
