import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_absolute_error

df = pd.read_csv("train.csv")

df = df.drop(columns=["X1", "X7"])

df["X3"] = df["X3"].replace({
    "low fat": "Low Fat",
    "LF":      "Low Fat",
    "reg":     "Regular"
})

df["X2"] = df["X2"].fillna(df["X2"].median())
df["X9"] = df["X9"].fillna(df["X9"].mode()[0])

X = df.drop(columns = ["Y"])
y = df["Y"]

categorical_columns = X.select_dtypes(include=["object","string"]).columns.tolist()
numerical_columns = X.select_dtypes(exclude=["object","string"]).columns.tolist()

one_hot_encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)

preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numerical_columns),
        ("cat", one_hot_encoder, categorical_columns)
    ]
)


X = preprocessor.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
   X, y, test_size = 0.2, random_state = 50)



X_submission = pd.read_csv("test.csv")
X_submission = X_submission.drop(columns=["X1", "X7"])

X_submission["X3"] = X_submission["X3"].replace({
    "low fat": "Low Fat",
    "LF":      "Low Fat",
    "reg":     "Regular"
})

X_submission["X2"] = X_submission["X2"].fillna(X_submission["X2"].median())
X_submission["X9"] = X_submission["X9"].fillna(X_submission["X9"].mode()[0])
X_submission = preprocessor.transform(X_submission)
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)

result = lin_reg.predict(X_test)
lin_mse = mean_absolute_error(y_test,result)
print(lin_mse)

result = lin_reg.predict(X_submission)
df = pd.read_csv("sample_submission.csv")
df["Y"] = result
df.to_csv("sample_submission.csv", index=False)
