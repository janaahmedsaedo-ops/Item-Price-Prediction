import pandas as pd
import numpy as np
from catboost import CatBoostRegressor
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge

df = pd.read_csv("train.csv")



df = df.drop(columns=["X1", "X7"])


df["X3"] = df["X3"].replace({
    "low fat": "Low Fat",
    "LF":      "Low Fat",
    "reg":     "Regular"
})


df["X2"] = df["X2"].fillna(df["X2"].median())
df["X9"] = df["X9"].fillna(df["X9"].mode()[0])

X = df.drop(columns = ["Y"])
y = df["Y"]

categorical_columns = X.select_dtypes(include=["object"]).columns.tolist()
numerical_columns = X.select_dtypes(exclude=["object"]).columns.tolist()

one_hot_encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)

preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numerical_columns),
        ("cat", one_hot_encoder, categorical_columns)
    ]
)

X_train, X_test, y_train, y_test = train_test_split( 
   X, y, test_size = 0.2, random_state = 30)

X_train = preprocessor.fit_transform(X_train)
X_test = preprocessor.transform(X_test)

ridge_model = Ridge(alpha=1.0)
ridge_model.fit(X_train, y_train)
y_pred = ridge_model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
print(f"MAE: {mae:.4f}")