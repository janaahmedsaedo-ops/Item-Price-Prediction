import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import lightgbm as lgb
from lightgbm import LGBMRegressor




df = pd.read_csv("train.csv")


df["X3"] = df["X3"].replace({"low fat": "Low Fat", "LF": "Low Fat", "reg": "Regular"})
df["X2"] = df["X2"].fillna(df["X2"].median())
df["X9"] = df["X9"].fillna(df["X9"].mode()[0])
df["X4"] = df["X4"].replace(0.0, df[df["X4"] > 0]["X4"].mean())
df["Outlet_Age"] = 2026 - df["X8"]
df = df.drop(columns=["X8"])

X = df.drop(columns=["Y"])
y = df["Y"]

cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
for col in cat_cols:
    X[col] = X[col].astype("category")



plt.figure(figsize=(8, 4))
plt.hist(y, bins=40, color="steelblue", edgecolor="white")
plt.title("Target (Y) Distribution")
plt.xlabel("Item Price")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("viz_target_distribution.png")
plt.show()


num_cols = df.select_dtypes(include=["number"]).columns.tolist()
plt.figure(figsize=(7, 5))
sns.heatmap(df[num_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("viz_correlation_heatmap.png")
plt.show()


plt.figure(figsize=(8, 4))
df.groupby("X11")["Y"].mean().sort_values().plot(kind="barh", color="teal")
plt.title("Mean Price by Outlet Type (X11)")
plt.xlabel("Mean Price (Y)")
plt.tight_layout()
plt.savefig("viz_outlet_type_mean_price.png")
plt.show()


plt.figure(figsize=(7, 5))
plt.scatter(df["X6"], y, alpha=0.4, s=12, color="steelblue")
plt.xlabel("Item MRP (X6)")
plt.ylabel("Target Price (Y)")
plt.title("Item MRP vs Target Price")
plt.tight_layout()
plt.savefig("viz_mrp_vs_target.png")
plt.show()


X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=20)


model = LGBMRegressor(
    objective="mae",
    n_estimators=5000,
    learning_rate=0.02,
    num_leaves=10,
    subsample=0.8,
    colsample_bytree=0.1,
    min_child_samples=6,
    extra_trees=True,
    reg_alpha=0.33,
    reg_lambda=0.37,
    random_state=15,
    verbose=-1
)

model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    categorical_feature=cat_cols,
    callbacks=[lgb.early_stopping(200, verbose=False)]
)


preds = model.predict(X_val)
mae = mean_absolute_error(y_val, preds)
print(f"\nValidation MAE: {mae:.4f}")
print(f"Best iteration: {model.best_iteration_}")


test_raw = pd.read_csv("test.csv")
test_df = test_raw.copy()
test_df["X3"] = test_df["X3"].replace({"low fat": "Low Fat", "LF": "Low Fat", "reg": "Regular"})
test_df["X2"] = test_df["X2"].fillna(test_df["X2"].median())
test_df["X9"] = test_df["X9"].fillna(test_df["X9"].mode()[0])
test_df["X4"] = test_df["X4"].replace(0.0, test_df[test_df["X4"] > 0]["X4"].mean())
test_df["Outlet_Age"] = 2026 - test_df["X8"]
test_df = test_df.drop(columns=["X8"], errors="ignore")

for col in cat_cols:
    test_df[col] = test_df[col].astype("category")

test_preds = model.predict(test_df)

submission = pd.DataFrame({
    "row_id": range(len(test_preds)),
    "Y": test_preds
})
submission.to_csv("submission_lightgbm_3.csv", index=False)