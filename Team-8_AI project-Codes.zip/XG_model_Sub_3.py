import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from xgboost import XGBRegressor


train = pd.read_csv("train.csv")
test  = pd.read_csv("test.csv")
sub   = pd.read_csv("sample_submission.csv")


train["X3"] = train["X3"].replace({"low fat": "Low Fat", "LF": "Low Fat", "reg": "Regular"})
train["X2"] = train["X2"].fillna(train["X2"].median())
train["X9"] = train["X9"].fillna(train["X9"].mode()[0])
train["X4"] = train["X4"].replace(0.0, train[train["X4"] > 0]["X4"].mean())
train = train.drop(columns=["X8"])

X = train.drop(columns=["Y"])
y = train["Y"]

cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
for col in cat_cols:
    X[col] = X[col].astype("category")


test["X3"] = test["X3"].replace({"low fat": "Low Fat", "LF": "Low Fat", "reg": "Regular"})
test["X2"] = test["X2"].fillna(train["X2"].median())
test["X9"] = test["X9"].fillna(train["X9"].mode()[0])
test["X4"] = test["X4"].replace(0.0, train[train["X4"] > 0]["X4"].mean())
test = test.drop(columns=["X8"])

cat_cols_test = test.select_dtypes(include=["object"]).columns.tolist()
for col in cat_cols_test:
    test[col] = pd.Categorical(test[col], categories=X[col].cat.categories)


X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=20)

model_es = XGBRegressor(
    n_estimators=2000,
    learning_rate=0.01,
    max_depth=3,
    subsample=0.85,
    colsample_bytree=0.8,
    min_child_weight=5,
    gamma=0.1,
    random_state=1,
    enable_categorical=True,
    tree_method="hist",
    eval_metric="mae",
    early_stopping_rounds=150
)

model_es.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    verbose=200
)

best_n = model_es.best_iteration
val_mae = mean_absolute_error(y_val, model_es.predict(X_val))
print(f"\nBest n_estimators: {best_n}")
print(f"Validation MAE:    {val_mae:.4f}")


model_full = XGBRegressor(
    n_estimators=best_n,
    learning_rate=0.01,
    max_depth=3,
    subsample=0.85,
    colsample_bytree=0.8,
    min_child_weight=5,
    gamma=0.1,
    random_state=1,
    enable_categorical=True,
    tree_method="hist",
    eval_metric="mae",
)

model_full.fit(X, y, verbose=200)


preds = model_full.predict(test)
sub["Y"] = preds
sub.to_csv("XG_4_submission.csv", index=False)

